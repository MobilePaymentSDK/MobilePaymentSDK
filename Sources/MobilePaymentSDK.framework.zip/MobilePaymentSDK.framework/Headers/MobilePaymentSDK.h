//
//  MobilePaymentSDK.h
//  MobilePaymentSDK
//
//  Created by Pankaj on 2/20/23.
//

#import <Foundation/Foundation.h>

//! Project version number for MobilePaymentSDK.
FOUNDATION_EXPORT double MobilePaymentSDKVersionNumber;

//! Project version string for MobilePaymentSDK.
FOUNDATION_EXPORT const unsigned char MobilePaymentSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MobilePaymentSDK/PublicHeader.h>

#import <ThreeDS_SDK/ThreeDS_SDK.h>
